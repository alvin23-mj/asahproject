import "regenerator-runtime";
import "../styles/styles.css";
import App from "./app.js";
import { initPushNotification } from "./utils/push-notification.js";

const app = new App({
  content: document.querySelector("#app-content"),
  navigation: document.querySelector("#main-navigation"),
});

window.addEventListener("hashchange", () => {
  app.renderPage();
});

window.addEventListener("load", () => {
  app.renderPage();

  if ("serviceWorker" in navigator) {
    navigator.serviceWorker
      .register("/sw.js")
      .then((registration) => {
        console.log("SW terdaftar: ", registration);
      })
      .catch((registrationError) => {
        console.log("Registrasi SW gagal: ", registrationError);
      });
  }

  initPushNotification();
});

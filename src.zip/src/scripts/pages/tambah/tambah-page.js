import { addNewStory } from "../../data/api.js";

const TambahPage = {
  async render() {
    return `
      <div class="page">
        <h1>Tambah Cerita Baru</h1>
        <form id="add-story-form">
          <div>
            <label for="story-image">Upload Gambar:</label>
            <input type="file" id="story-image" name="photo" accept="image/*" required>
          </div>
          <div>
            <label for="story-desc">Deskripsi:</label>
            <textarea id="story-desc" name="description" rows="5" required></textarea>
          </div>
          <p>Klik di peta untuk memilih lokasi:</p>
          <div id="map-select"></div>
          <input type="hidden" id="story-lat" name="lat" required>
          <input type="hidden" id="story-lon" name="lon" required>
          
          <button type="submit" id="submit-button">Upload</button>
        </form>
        <div id="form-message" role="alert"></div>
      </div>
    `;
  },

  async afterRender() {
    const map = L.map("map-select").setView([-6.2, 106.816666], 10);
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png").addTo(
      map
    );

    let selectedMarker;
    const latInput = document.getElementById("story-lat");
    const lonInput = document.getElementById("story-lon");

    map.on("click", (e) => {
      const { lat, lng } = e.latlng;
      latInput.value = lat;
      lonInput.value = lng;

      if (selectedMarker) {
        selectedMarker.setLatLng([lat, lng]);
      } else {
        selectedMarker = L.marker([lat, lng]).addTo(map);
      }
    });

    const form = document.getElementById("add-story-form");
    const messageEl = document.getElementById("form-message");
    const submitButton = document.getElementById("submit-button");

    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      submitButton.disabled = true;
      messageEl.textContent = "Mengupload...";
      messageEl.className = "";

      if (!latInput.value || !lonInput.value) {
        messageEl.textContent = "Error: Silakan pilih lokasi di peta.";
        messageEl.className = "error";
        submitButton.disabled = false;
        return;
      }

      try {
        const formData = new FormData(form);
        await addNewStory(formData);

        messageEl.textContent = "Sukses! Cerita berhasil di-upload.";
        messageEl.className = "success";
        form.reset();
        map.removeLayer(selectedMarker);
        selectedMarker = null;
        setTimeout(() => {
          window.location.hash = "#/home";
        }, 1000);
      } catch (error) {
        messageEl.textContent = `Error: ${error.message}`;
        messageEl.className = "error";
      } finally {
        submitButton.disabled = false;
      }
    });
  },
};

export default TambahPage;

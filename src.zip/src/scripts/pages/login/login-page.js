import { loginUser } from "../../data/api.js";

const LoginPage = {
  async render() {
    return `
      <div class="page auth-page">
        <h1>Login</h1>
        <form id="login-form">
          <div>
            <label for="login-email">Email:</label>
            <input type="email" id="login-email" name="email" required>
          </div>
          <div>
            <label for="login-password">Password:</label>
            <input type="password" id="login-password" name="password" required>
          </div>
          <button type="submit" id="submit-button">Login</button>
        </form>
        <div id="form-message" role="alert"></div>
        <p>Belum punya akun? <a href="#/register">Daftar di sini</a></p>
      </div>
    `;
  },

  async afterRender() {
    const form = document.getElementById("login-form");
    const messageEl = document.getElementById("form-message");
    const submitButton = document.getElementById("submit-button");

    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      submitButton.disabled = true;
      messageEl.textContent = "Logging in...";
      messageEl.className = "";

      try {
        const email = document.getElementById("login-email").value;
        const password = document.getElementById("login-password").value;

        await loginUser({ email, password });

        messageEl.textContent = "Login berhasil! Mengarahkan...";
        messageEl.className = "success";

        setTimeout(() => {
          window.location.hash = "#/home";
          window.location.reload();
        }, 1000);
      } catch (error) {
        messageEl.textContent = `Error: ${error.message}`;
        messageEl.className = "error";
        submitButton.disabled = false;
      }
    });
  },
};

export default LoginPage;

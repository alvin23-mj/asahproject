import { registerUser } from "../../data/api.js";

const RegisterPage = {
  async render() {
    return `
      <div class="page auth-page">
        <h1>Daftar Akun Baru</h1>
        <form id="register-form">
          <div>
            <label for="reg-name">Nama:</label>
            <input type="text" id="reg-name" name="name" required>
          </div>
          <div>
            <label for="reg-email">Email:</label>
            <input type="email" id="reg-email" name="email" required>
          </div>
          <div>
            <label for="reg-password">Password:</label>
            <input type="password" id="reg-password" name="password" minlength="8" required>
          </div>
          <button type="submit" id="submit-button">Daftar</button>
        </form>
        <div id="form-message" role="alert"></div>
        <p>Sudah punya akun? <a href="#/login">Login di sini</a></p>
      </div>
    `;
  },

  async afterRender() {
    const form = document.getElementById("register-form");
    const messageEl = document.getElementById("form-message");
    const submitButton = document.getElementById("submit-button");

    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      submitButton.disabled = true;
      messageEl.textContent = "Mendaftarkan...";
      messageEl.className = "";

      try {
        const name = document.getElementById("reg-name").value;
        const email = document.getElementById("reg-email").value;
        const password = document.getElementById("reg-password").value;

        await registerUser({ name, email, password });

        messageEl.textContent = "Pendaftaran berhasil! Silakan login.";
        messageEl.className = "success";
        form.reset();

        setTimeout(() => {
          window.location.hash = "#/login";
        }, 2000);
      } catch (error) {
        messageEl.textContent = `Error: ${error.message}`;
        messageEl.className = "error";
        submitButton.disabled = false;
      }
    });
  },
};

export default RegisterPage;

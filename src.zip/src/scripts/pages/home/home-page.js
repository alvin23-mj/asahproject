import { getStoriesWithLocation } from "../../data/api.js";
import { addStory, getStory } from "../../data/idb-helper.js";

const HomePage = {
  async render() {
    return `
      <div class="page">
        <h1>Peta Cerita</h1>
        <div class="home-container">
          <div id="map"></div>
          <div id="story-list-container">
            <h2>Daftar Cerita</h2>
            <div id="story-list">Memuat cerita...</div>
          </div>
        </div>
      </div>
    `;
  },

  async afterRender() {
    try {
      const map = L.map("map").setView([-6.2, 106.816666], 10);
      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png").addTo(
        map
      );

      const data = await getStoriesWithLocation();
      const listEl = document.getElementById("story-list");
      listEl.innerHTML = "";

      const markers = {};

      data.listStory.forEach(async (story) => {
        const storyDate = new Date(story.createdAt);
        const formattedDate = storyDate.toLocaleDateString("id-ID", {
          day: "numeric",
          month: "long",
          year: "numeric",
        });

        const storyItem = document.createElement("article");
        storyItem.innerHTML = `
          <img src="${story.photoUrl}" alt="Foto cerita oleh ${story.name}">
          <h3>${story.name}</h3>
          <p class="story-date">${formattedDate}</p>
          <p>${story.description.substring(0, 100)}...</p>
          <button class="favorite-button" data-id="${story.id}">
            Simpan ke Favorit
          </button>
        `;
        listEl.appendChild(storyItem);

        const favButton = storyItem.querySelector(".favorite-button");
        const isFavorited = await getStory(story.id);
        if (isFavorited) {
          favButton.textContent = "Tersimpan";
          favButton.disabled = true;
        }

        favButton.addEventListener("click", async (e) => {
          e.stopPropagation();
          await addStory(story);
          e.target.textContent = "Tersimpan";
          e.target.disabled = true;
        });

        const marker = L.marker([story.lat, story.lon])
          .addTo(map)
          .bindPopup(`<b>${story.name}</b>`);

        markers[story.id] = marker;

        storyItem.addEventListener("click", () => {
          map.flyTo([story.lat, story.lon], 13);
          marker.openPopup();
        });
      });
    } catch (error) {
      console.error(error);
      document.getElementById("story-list").innerHTML = `
        <p style="color: red;">Error: ${error.message}. 
        Pastikan Anda sudah login atau token valid.</p>`;
    }
  },
};

export default HomePage;

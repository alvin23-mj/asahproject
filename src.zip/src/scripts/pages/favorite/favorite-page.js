import { getAllStories, deleteStory } from "../../data/idb-helper.js";

const FavoritePage = {
  async render() {
    return `
      <div class="page">
        <h1>Cerita Favorit</h1>
        <div class="form">
          <label for="search-favorite">Cari Cerita</label>
          <input id="search-favorite" type="text" placeholder="Cari berdasarkan nama...">
        </div>
        <div id="favorite-list-container">
          <div id="favorite-list" class="story-list">
            Memuat cerita favorit...
          </div>
        </div>
      </div>
    `;
  },

  async afterRender() {
    const storiesContainer = document.getElementById("favorite-list");
    const searchInput = document.getElementById("search-favorite");

    const renderFavorites = async (query = "") => {
      try {
        const stories = await getAllStories();
        storiesContainer.innerHTML = "";

        const filteredStories = stories.filter((story) =>
          story.name.toLowerCase().includes(query.toLowerCase())
        );

        if (filteredStories.length === 0) {
          storiesContainer.innerHTML = "<p>Belum ada cerita favorit.</p>";
          return;
        }

        filteredStories.forEach((story) => {
          const storyItem = document.createElement("article");
          storyItem.innerHTML = `
            <img src="${story.photoUrl}" alt="Foto cerita oleh ${story.name}">
            <h2>${story.name}</h2>
            <p>${story.description.substring(0, 100)}...</p>
            <button class="delete-button" data-id="${
              story.id
            }">Hapus dari Favorit</button>
          `;
          storiesContainer.appendChild(storyItem);
        });
      } catch (error) {
        storiesContainer.innerHTML = `<p>Gagal memuat favorit: ${error.message}</p>`;
      }
    };

    searchInput.addEventListener("input", (e) => {
      renderFavorites(e.target.value);
    });

    storiesContainer.addEventListener("click", async (e) => {
      if (e.target.classList.contains("delete-button")) {
        const storyId = e.target.dataset.id;
        try {
          await deleteStory(storyId);
          renderFavorites(searchInput.value);
        } catch (error) {
          console.error("Gagal menghapus:", error);
        }
      }
    });

    renderFavorites();
  },
};

export default FavoritePage;

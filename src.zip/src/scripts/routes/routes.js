import HomePage from "../pages/home/home-page.js";
import TambahPage from "../pages/tambah/tambah-page.js";
import LoginPage from "../pages/login/login-page.js";
import RegisterPage from "../pages/register/register-page.js";
import FavoritePage from "../pages/favorite/favorite-page.js"; // <-- IMPORT BARU

const routes = {
  "/": LoginPage,
  "/home": HomePage,
  "/tambah": TambahPage,
  "/login": LoginPage,
  "/register": RegisterPage,
  "/favorite": FavoritePage, // <-- RUTE BARU
};

export default routes;

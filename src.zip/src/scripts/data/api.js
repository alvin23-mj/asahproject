import { API_BASE_URL } from "../utils/config.js";

function getToken() {
  return localStorage.getItem("apiToken");
}

function saveToken(token) {
  localStorage.setItem("apiToken", token);
}

export function removeToken() {
  localStorage.removeItem("apiToken");
}

async function fetchWithAuth(url, options = {}) {
  const token = getToken();
  const headers = {
    ...options.headers,
  };

  if (token) {
    headers["Authorization"] = `Bearer ${token}`;
  }

  const response = await fetch(url, { ...options, headers });

  if (!response.ok) {
    const errorData = await response.json();
    throw new Error(errorData.message || "Terjadi kesalahan pada server");
  }

  return response.json();
}

async function fetchWithoutAuth(url, options = {}) {
  const response = await fetch(url, options);
  if (!response.ok) {
    const errorData = await response.json();
    throw new Error(errorData.message || "Terjadi kesalahan");
  }
  return response.json();
}

export async function registerUser({ name, email, password }) {
  const options = {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name, email, password }),
  };
  return fetchWithoutAuth(`${API_BASE_URL}/register`, options);
}

export async function loginUser({ email, password }) {
  const options = {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email, password }),
  };

  const data = await fetchWithoutAuth(`${API_BASE_URL}/login`, options);

  if (data.loginResult && data.loginResult.token) {
    saveToken(data.loginResult.token);
  }
  return data;
}

export async function getStoriesWithLocation() {
  return fetchWithAuth(`${API_BASE_URL}/stories?location=1`);
}

export async function addNewStory(formData) {
  const token = getToken();
  if (!token) throw new Error("Anda harus login untuk menambah cerita");

  const response = await fetch(`${API_BASE_URL}/stories`, {
    method: "POST",
    headers: { Authorization: `Bearer ${token}` },
    body: formData,
  });

  if (!response.ok) {
    const errorData = await response.json();
    throw new Error(errorData.message || "Gagal mengupload cerita");
  }

  return response.json();
}

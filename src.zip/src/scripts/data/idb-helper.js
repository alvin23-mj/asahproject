import { openDB } from "idb";
import { API_BASE_URL } from "../utils/config.js";

const DB_NAME = "myapp-db-v1";
const STORE_NAME = "favorite-stories";

const dbPromise = openDB(DB_NAME, 1, {
  upgrade(db) {
    db.createObjectStore(STORE_NAME, { keyPath: "id" });
  },
});

export const getStory = async (id) => {
  return (await dbPromise).get(STORE_NAME, id);
};

export const getAllStories = async () => {
  return (await dbPromise).getAll(STORE_NAME);
};

export const addStory = async (story) => {
  return (await dbPromise).put(STORE_NAME, story);
};

export const deleteStory = async (id) => {
  return (await dbPromise).delete(STORE_NAME, id);
};

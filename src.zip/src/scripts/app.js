import UrlParser from "./routes/url-parser.js";
import routes from "./routes/routes.js";
import { removeToken } from "./data/api.js";

class App {
  constructor({ content, navigation }) {
    this._content = content;
    this._navigation = navigation;
    this._initialAppShell();
  }

  _initialAppShell() {
    const token = localStorage.getItem("apiToken");
    if (token) {
      this._navigation.innerHTML = `
        <a href="#/home">Beranda</a>
        <a href="#/tambah">Tambah Data</a>
        <a href="#/favorite">Favorit</a>
        <a href="#" id="logout-button">Logout</a>
      `;

      document
        .getElementById("logout-button")
        .addEventListener("click", (e) => {
          e.preventDefault();
          removeToken();
          window.location.hash = "#/login";
          window.location.reload();
        });
    } else {
      this._navigation.innerHTML = `
        <a href="#/login">Login</a>
        <a href="#/register">Register</a>
      `;
    }
  }

  async renderPage() {
    const url = UrlParser.parseActiveUrlWithoutCombiner();
    const token = localStorage.getItem("apiToken");

    const protectedRoutes = ["/home", "/tambah", "/favorite"];
    const guestRoutes = ["/login", "/register"];

    let pageUrl = url;

    if (token) {
      if (url === "/") pageUrl = "/home";
      if (guestRoutes.includes(url)) pageUrl = "/home";
    } else {
      if (url === "/") pageUrl = "/login";
      if (protectedRoutes.includes(url)) pageUrl = "/login";
    }

    if (pageUrl !== url) {
      window.location.hash = `#${pageUrl}`;
      return;
    }

    const page = routes[pageUrl] || routes["/"];

    if (!document.startViewTransition) {
      this._content.innerHTML = await page.render();
      await page.afterRender();
    } else {
      document.startViewTransition(async () => {
        this._content.innerHTML = await page.render();
        await page.afterRender();
      });
    }

    const skipLink = document.querySelector(".skip-link");
    skipLink.addEventListener("click", (e) => {
      e.preventDefault();
      document.querySelector("#app-content").focus();
    });
  }
}

export default App;

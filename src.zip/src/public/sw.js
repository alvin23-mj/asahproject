/* eslint-disable no-restricted-globals */

const CACHE_NAME = "myapp-cache-v1";

const URLS_TO_CACHE = [
  "/",
  "/index.html",
  "/app.bundle.js",
  "/app.css",
  "/manifest.webmanifest",
  "/images/logo.png",
  "/images/logo-192.png",
  "/images/logo-512.png",
  "https://unpkg.com/leaflet@1.9.4/dist/leaflet.css",
  "https://unpkg.com/leaflet@1.9.4/dist/leaflet.js",
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      console.log("Opened cache");
      return cache.addAll(URLS_TO_CACHE);
    })
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheName !== CACHE_NAME) {
            console.log(`Service Worker: Menghapus cache lama: ${cacheName}`);
            return caches.delete(cacheName);
          }
          return null;
        })
      );
    })
  );
});

self.addEventListener("fetch", (event) => {
  const requestUrl = new URL(event.request.url);

  if (requestUrl.origin === "https://story-api.dicoding.dev") {
    event.respondWith(fetch(event.request));
    return;
  }

  event.respondWith(
    caches.match(event.request).then((response) => {
      return response || fetch(event.request);
    })
  );
});

self.addEventListener("push", (event) => {
  console.log("Push event diterima!");

  let data;
  try {
    data = event.data.json();
  } catch (e) {
    data = { title: "Notifikasi Baru", body: event.data.text() };
  }

  const title = data.title;
  const options = {
    body: data.body,
    icon: "images/logo-192.png",
    badge: "images/logo-192.png",
  };

  event.waitUntil(self.registration.showNotification(title, options));
});
